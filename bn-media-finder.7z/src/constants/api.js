export const API_SITE = '//www.omdbapi.com';
export const API_KEY = 'f74ca8f1';
